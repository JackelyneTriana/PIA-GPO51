from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('productos',views.productos,name="productos"),
    path('Nosotros',views.Nosotros,name="Nosotros"),
    path('Contacto',views.Contacto,name="Contacto"),
]
