from django.db import models

# Create your models here.

class estantería(models.Model):
    marca = models.CharField(max_length=60)
    descripcion = models.CharField(max_length=60)
    precio = models.FloatField()
    
    def __str__(self):
        return self.descripcion

class locker(models.Model):
    marca = models.CharField(max_length=160)
    descripcion = models.CharField(max_length=160)
    precio = models.FloatField()
    
    def __str__(self):
        return self.descripcion

class mueble(models.Model):
    marca = models.CharField(max_length=160)
    descripcion = models.CharField(max_length=160)
    precio = models.FloatField()
    
    def __str__(self):
        return self.descripcion

class caja(models.Model):
    material = models.CharField(max_length=160)
    descripcion = models.CharField(max_length=160)
    precio = models.FloatField()
    
    def __str__(self):
        return self.descripcion