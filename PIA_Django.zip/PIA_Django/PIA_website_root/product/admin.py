from django.contrib import admin
from .models import caja, estantería, locker, mueble, caja

# Register your models here.
admin.site.register(estantería)
admin.site.register(locker)
admin.site.register(mueble)
admin.site.register(caja)