from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request,'index.html')

def productos(request):
    return render(request,'productos.html')

def Nosotros(request):
    return render(request,'Nosotros.html')

def Contacto(request):
    return render(request,'Contacto.html')